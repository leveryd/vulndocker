package com.firestar.demotwo;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

/**
 * Created by xiangzi on 2017/6/17.
 * 客户端测试，在客户端调用远程对象上的远程方法，并返回结果。
 */
public class HelloClient {
    public static void main(String args[]){
        try {

            //在RMI服务注册表中查找名称为RHello的对象，并调用其上的方法
            com.firestar.demotwo.IHello rhello =(com.firestar.demotwo.IHello) Naming.lookup("rmi://"+args[0]+":"+args[1]+"/Hello");
            System.out.println(rhello.helloWorld());
            System.out.println(rhello.sayHelloToSomeBody("熔岩"));
            com.firestar.demotwo.IRMIService service =(com.firestar.demotwo.IRMIService)Naming.lookup("rmi://"+args[0]+":"+args[1]+"/service");
            System.out.println(service.add(1,2));
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
