package com.firestar.demotwo;

import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.Random;

/**
 * Created by xiangzi on 2017/6/17.
 * 创建RMI注册表，启动RMI服务，并将远程对象注册到RMI注册表中。
 */
public class HelloServer {

    public static int getport() {
        int max=9050;
        int min=9000;
        Random random = new Random();

        int s = random.nextInt(max)%(max-min+1) + min;
        System.out.println(s);
        return s;
    }
    public static void main(String args[]) {

        try {
            /*
                java.rmi.server.hostname 必须要设置,否则远程不能调用。会报错
                参考:https://stackoverflow.com/questions/15685686/java-rmi-connectexception-connection-refused-to-host-127-0-1-1
             */
            System.setProperty("java.rmi.server.hostname","10.0.1.28");

            //创建一个远程对象
            IHello rhello = new HelloImpl();
            IRMIService service = new IRMIServiceImpl();
            int port = getport();
            //本地主机上的远程对象注册表Registry的实例，并指定端口为8888，这一步必不可少（Java默认端口是1099），必不可缺的一步，缺少注册表创建，则无法绑定对象到远程注册表上
            LocateRegistry.createRegistry(port);
            try {
                FileWriter writer = new FileWriter("/tmp/port");
                writer.write(Integer.toString(port));
                writer.close();
            } catch (IOException e)
            {

            }

            //把远程对象注册到RMI注册服务器上，并命名为RHello
            //绑定的URL标准格式为：rmi://host:port/name(其中协议名可以省略，下面两种写法都是正确的）
            Naming.bind("rmi://10.0.1.28:"+ Integer.toString(port) +"/Hello",rhello);

            System.out.println(">>>>>INFO:远程IHello对象绑定成功！");
            Naming.bind("rmi://10.0.1.28:"+ Integer.toString(port) +"/service",service);
//            Naming.bind("//localhost:8888/RHello",rhello);
            System.out.println(">>>>>INFO:远程IRMIService对象绑定成功！");

        } catch (RemoteException e) {
            System.out.println("创建远程对象发生异常！");
            e.printStackTrace();
        } catch (AlreadyBoundException e) {
            System.out.println("发生重复绑定对象异常！");
            e.printStackTrace();
        } catch (MalformedURLException e) {
            System.out.println("发生URL畸形异常！");
            e.printStackTrace();
        }
    }
}
