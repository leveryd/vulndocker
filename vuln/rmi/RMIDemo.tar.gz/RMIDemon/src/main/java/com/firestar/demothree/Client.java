package com.firestar.demothree;

/**
 * Created by xiangzi on 2017/6/17.
 */
public class Client {
    public static void main(String[] args) throws Exception {
        com.firestar.demothree.ServiceConsumer consumer = new com.firestar.demothree.ServiceConsumer();

        while (true) {
            com.firestar.demothree.HelloService helloService = consumer.lookup();
            String result = helloService.sayHello("Jack");
            System.out.println(result);
            Thread.sleep(3000);
        }
    }
}
