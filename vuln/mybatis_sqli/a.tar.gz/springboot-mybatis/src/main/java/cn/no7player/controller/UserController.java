package cn.no7player.controller;

import cn.no7player.model.User;
import cn.no7player.service.UserService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Created by zl on 2015/8/27.
 */
@Controller
public class UserController {

    private Logger logger = Logger.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @RequestMapping("/getUserInfo")
    @ResponseBody
    public User getUserInfo() {
        User user = userService.getUserInfo();
        if(user!=null){
            System.out.println("user.getName():"+user.getName());
            logger.info("user.getAge():"+user.getAge());
        }
        return user;
    }
    @RequestMapping(value="/getUserInfoOrder/{ordername}",method=RequestMethod.GET)
    @ResponseBody
    public User getUserInfoOrder(@PathVariable String ordername) {
        User user = userService.getUserInfoOrderby(ordername);
        if(user!=null){
            System.out.println("user.getName():"+user.getName());
            logger.info("user.getAge():"+user.getAge());
        }
        return user;
    }
    @RequestMapping(value="/insert/{name}",method=RequestMethod.GET)
    @ResponseBody
    public void inesrtUserInfo(@PathVariable Integer name,@RequestParam(value = "testxx", defaultValue = "12") String testxx) {
        userService.insertUserInfo(testxx);
    }
}
